﻿$rootMgmt = "Root Management Group ID"

New-AzPolicyDefinition -Name 'Audit Nic Orphaned' -DisplayName 'Audit Nic Orphaned' -Policy .\auditorphanednic.json -ManagementGroupName $rootMgmt -Metadata '{"category":"Cost Optimization"}'

New-AzPolicyDefinition -Name 'Audit Public IP Orphaned' -DisplayName 'Audit Public IP Orphaned' -Policy auditorphanedpublicip.json -ManagementGroupName $rootMgmt -Metadata '{"category":"Cost Optimization"}'

New-AzPolicyDefinition -Name 'Audit Disks Orphaned' -DisplayName 'Audit Disks Orphaned' -Policy .\auditorphaneddisks.json -ManagementGroupName $rootMgmt -Metadata '{"category":"Cost Optimization"}'

New-AzPolicyDefinition -Name 'Audit Aplication Gateway Orphaned' -DisplayName 'Audit Aplication Gateway Orphaned' -Policy .\auditorphanedapplicationgateway.json -ManagementGroupName $rootMgmt -Metadata '{"category":"Cost Optimization"}'

New-AzPolicyDefinition -Name 'Audit Load Balancer Orphaned' -DisplayName 'Audit Load Balancer Orphaned' -Policy .\auditorphanedloadbalancer.json -ManagementGroupName $rootMgmt -Metadata '{"category":"Cost Optimization"}'

New-AzPolicyDefinition -Name 'Audit Availability Set Orphaned' -DisplayName 'Audit Availability Set Orphaned' -Policy .\auditorphanedavailabilityset.json -ManagementGroupName $rootMgmt -Metadata '{"category":"Cost Optimization"}'
